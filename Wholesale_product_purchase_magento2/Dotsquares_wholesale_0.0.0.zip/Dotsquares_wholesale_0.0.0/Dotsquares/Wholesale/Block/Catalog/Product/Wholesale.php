<?php
namespace Dotsquares\Wholesale\Block\Catalog\Product;

class Wholesale extends \Magento\Framework\View\Element\Template
{
    	public function _prepareLayout()
	{
		return parent::_prepareLayout();
	}
}
